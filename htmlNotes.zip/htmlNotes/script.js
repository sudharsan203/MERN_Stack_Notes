console.log("Checking the sample html page")
let greet = function (){
    return "Hello!"
}
greet();
let firstName = "John"